'use strict';

const crypto = require('node:crypto');
const { generationWaitMessage } = require('../utils/generation-timeout');
const adapter = require('../adapters/openai-images');
const { AppError, publicError } = require('../utils/errors');
const { assertUuidLike, validatePrompt } = require('../utils/validation');
const MAX_TAG_RESULTS = 8;

function timestamp() { return new Date().toISOString(); }

class GenerationService {
  constructor({ metadata, preset, storage, retryDelays }) {
    this.metadata = metadata;
    this.preset = preset;
    this.storage = storage;
    this.retryDelays = retryDelays;
    this.running = new Map();
    this.creationLocks = new Map();
  }

  async resolveTags(tagIds) {
    return tagIds.map(tagId => {
      const tag = this.metadata.getTag(tagId);
      if (!tag) return { tagId, tag: null, attempts: [], results: [] };
      const attempts = Object.values(this.metadata.index.attempts)
        .filter(item => item.tagId === tagId)
        .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
      const results = tag.resultIds.map(id => this.metadata.getResult(id)).filter(Boolean);
      return { tagId, tag, attempts, results };
    });
  }

  async generate(input) {
    const rawAttemptId = String(input?.attemptId ?? '');
    if (this.creationLocks.has(rawAttemptId)) {
      return this.creationLocks.get(rawAttemptId);
    }
    const pending = this.createAttempt(input);
    this.creationLocks.set(rawAttemptId, pending);
    try {
      return await pending;
    } finally {
      this.creationLocks.delete(rawAttemptId);
    }
  }

  async createAttempt(input) {
    const tagId = assertUuidLike(input.tagId, 'tagId');
    const attemptId = assertUuidLike(input.attemptId, 'attemptId', { allowAuto: true });
    const prompt = validatePrompt(input.prompt);
    const requestMode = input.requestMode === 'auto' ? 'auto' : 'manual';
    if (requestMode === 'auto' && attemptId !== `auto:${tagId}`) {
      throw new AppError('VALIDATION_FAILED', '自动生图幂等键无效');
    }

    const existing = this.metadata.getAttempt(attemptId);
    if (existing) return existing;

    const preset = await this.preset.get();
    const apiKey = await this.preset.getSecret();
    const settings = await this.preset.getSettings();
    const parameters = {
      size: input.parameters?.size
        || preset.ratioMap?.[input.parameters?.ratio]
        || preset.defaultSize,
      quality: input.parameters?.quality || preset.defaultQuality,
      count: Math.min(4, Math.max(1, Number(input.parameters?.count) || preset.defaultCount)),
      extraBody: input.parameters?.extraBody || {},
    };
    const attempt = {
      attemptId,
      tagId,
      requestMode,
      parallel: input.parallel === true,
      presetId: 'default',
      presetNameSnapshot: preset.name,
      model: preset.selectedModel,
      promptSnapshot: prompt,
      parameters,
      status: 'queued',
      resultIds: [],
      errorCode: null,
      errorMessage: null,
      createdAt: timestamp(),
      completedAt: null,
      schemaVersion: 1,
    };
    const tag = this.metadata.getTag(tagId) || {
      tagId,
      chatId: String(input.chatId || ''),
      messageUuid: String(input.messageUuid || ''),
      tagOrdinal: Number(input.tagOrdinal) || 0,
      prompt,
      latestResultId: null,
      resultIds: [],
      autoAttempted: requestMode === 'auto',
      autoSuppressed: false,
      createdAt: timestamp(),
      updatedAt: timestamp(),
      schemaVersion: 1,
    };
    await this.metadata.transaction(index => {
      index.tags[tagId] ||= tag;
      if (requestMode === 'auto') index.tags[tagId].autoAttempted = true;
      index.attempts[attemptId] = attempt;
    });

    const controller = new AbortController();
    this.running.set(attemptId, controller);
    void this.execute({ attempt, tag, preset, apiKey, settings, prompt, parameters, controller });
    return attempt;
  }

  async execute(context) {
    const { attempt, tag, preset, apiKey, settings, prompt, parameters, controller } = context;
    try {
      attempt.status = 'generating';
      await this.metadata.putAttempt(attempt);
      const sources = await adapter.generate({
        preset,
        apiKey,
        settings,
        prompt,
        parameters,
        signal: controller.signal,
        retryDelays: this.retryDelays,
        onRequestParameters: values => Object.assign(attempt.parameters, values),
        onPolling: async message => {
          attempt.statusMessage = message;
          await this.metadata.putAttempt(attempt);
        },
        onTimeout: async timeoutMs => {
          if (attempt.status !== 'generating' || controller.signal.aborted) return;
          attempt.statusMessage = generationWaitMessage(timeoutMs);
          await this.metadata.putAttempt(attempt);
        },
        onRetry: async retry => {
          attempt.retryCount = retry.retryCount;
          attempt.retryNotice = retry;
          attempt.statusMessage = retry.message;
          await this.metadata.putAttempt(attempt);
        },
        onCompatibilityRetry: async retry => {
          attempt.compatibilityRetry = retry;
          attempt.statusMessage = retry.message;
          await this.metadata.putAttempt(attempt);
        },
      });
      attempt.statusMessage = null;
      for (const source of sources) {
        if (controller.signal.aborted) throw new AppError('ATTEMPT_INTERRUPTED', '用户已取消');
        attempt.status = source.sourceType === 'url' ? 'downloading' : 'saving';
        await this.metadata.putAttempt(attempt);
        const resultId = crypto.randomUUID();
        const saved = await this.storage.saveSource(source, resultId, controller.signal);
        attempt.status = 'saving';
        await this.metadata.putAttempt(attempt);
        const result = {
          resultId,
          attemptId: attempt.attemptId,
          tagId: tag.tagId,
          generationIndex: source.generationIndex,
          chatId: tag.chatId,
          messageUuid: tag.messageUuid,
          prompt,
          negativePrompt: '',
          provider: 'openai',
          presetId: 'default',
          presetNameSnapshot: preset.name,
          apiModel: preset.selectedModel,
          parameters: { size: attempt.parameters?.size ?? null, quality: attempt.parameters?.quality ?? null },
          ...saved,
          sourceType: source.sourceType,
          status: 'available',
          generationDurationMs: Math.max(0, Date.now() - Date.parse(attempt.createdAt)),
          createdAt: timestamp(),
          favorite: false,
          compatibilityRetry: attempt.compatibilityRetry || null,
          schemaVersion: 1,
        };
        await this.metadata.putResult(result);
        attempt.resultIds.push(resultId);
      }
      if (controller.signal.aborted) throw new AppError('ATTEMPT_INTERRUPTED', '用户已取消');
      attempt.status = 'succeeded';
      attempt.completedAt = timestamp();
      tag.updatedAt = timestamp();
      let obsoleteIds = [];
      await this.metadata.transaction(index => {
        if (controller.signal.aborted) throw new AppError('ATTEMPT_INTERRUPTED', '用户已取消');
        index.attempts[attempt.attemptId] = attempt;
        const current = index.tags[tag.tagId] || { ...tag, resultIds: [] };
        const allIds = [...new Set([...(current.resultIds || []), ...attempt.resultIds])];
        obsoleteIds = allIds.slice(0, -MAX_TAG_RESULTS);
        current.resultIds = allIds.slice(-MAX_TAG_RESULTS);
        current.latestResultId = attempt.resultIds.at(-1) || current.latestResultId;
        current.updatedAt = timestamp();
        index.tags[tag.tagId] = current;
      });
      const removed = [];
      for (const id of obsoleteIds) {
        const old = this.metadata.getResult(id);
        try {
          if (old?.localRelativePath) await this.storage.remove(old.localRelativePath);
          removed.push(id);
        } catch (error) {
          console.warn('[画笺] 历史图片硬删除失败', id, error);
        }
      }
      if (removed.length) {
        await this.metadata.transaction(index => {
          for (const id of removed) delete index.results[id];
        }).catch(error => console.warn('[画笺] 历史图片元数据删除失败', error));
      }
    } catch (error) {
      for (const resultId of attempt.resultIds) {
        const partial = this.metadata.getResult(resultId);
        if (partial?.localRelativePath) {
          await this.storage.remove(partial.localRelativePath).catch(() => {});
        }
      }
      const discarded = new Set(attempt.resultIds);
      attempt.resultIds = [];
      const cancelled = controller.signal.aborted;
      const exposed = publicError(error);
      attempt.status = cancelled ? 'cancelled' : 'failed';
      attempt.errorCode = cancelled ? null : exposed.code;
      attempt.errorMessage = cancelled
        ? '已取消'
        : `${exposed.message}${exposed.details ? `：${exposed.details}` : ''}`;
      if (!cancelled && attempt.compatibilityRetry) {
        attempt.errorMessage += `；已尝试移除 ${attempt.compatibilityRetry.adjustedParameters.join('、')} 后重试一次`;
      }
      attempt.completedAt = timestamp();
      await this.metadata.transaction(index => {
        for (const resultId of discarded) delete index.results[resultId];
        const storedTag = index.tags[tag.tagId];
        if (storedTag) {
          storedTag.resultIds = (storedTag.resultIds || [])
            .filter(resultId => !discarded.has(resultId));
          if (discarded.has(storedTag.latestResultId)) {
            storedTag.latestResultId = storedTag.resultIds.at(-1) || null;
          }
        }
        index.attempts[attempt.attemptId] = attempt;
      });
    } finally {
      this.running.delete(attempt.attemptId);
    }
  }

  async cancel(attemptId) {
    const attempt = this.metadata.getAttempt(attemptId);
    if (!attempt) throw new AppError('NOT_FOUND', 'attempt 不存在', 404);
    this.running.get(attemptId)?.abort();
    if (['queued', 'generating', 'downloading', 'saving'].includes(attempt.status)) {
      attempt.status = 'cancelled';
      attempt.completedAt = timestamp();
      await this.metadata.putAttempt(attempt);
    }
    return attempt;
  }
}

module.exports = { GenerationService };
